sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("incidentmanagement.Incidents.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);